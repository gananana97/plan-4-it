const Event = require('./Event');
const RSVP = require('./RSVP');

module.exports = { Event, RSVP };
