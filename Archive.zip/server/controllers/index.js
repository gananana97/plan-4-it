// controllers/index.js
const apiControllers = require('./api');
const homeRoutes = require('./home-routes');

module.exports = {
  apiControllers,
  homeRoutes,
};
