import React, { useContext } from 'react';
import { UserContext } from '../context/UserContext';  // Import UserContext

const DashboardPanel = () => {
  const { user } = useContext(UserContext);  // Access user data from context

  if (!user) {
    return <div>No user data available. Please log in.</div>;
  }

  return (
    <div>
      <h1>Welcome, {user.username}!</h1>
      {/* Add other user-specific dashboard content here */}
    </div>
  );
};

export default DashboardPanel;
