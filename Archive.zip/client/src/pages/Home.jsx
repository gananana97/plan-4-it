import React from 'react';

const Home = () => {
  return (
    <div>
      <div className="home-content">
        <p>
          Organize your events, manage your attendees, and much more with our platform!
        </p>
      </div>
    </div>
  );
};

export default Home;
