import React, { useContext, useState, useEffect } from 'react';
import { UserContext } from '../context/UserContext';
import EventList from '../components/EventList';  // Assuming you already have this component
import api from '../utils/api';

const DashboardPanel = () => {
  const { user } = useContext(UserContext);  // Access user data from context
  const [events, setEvents] = useState([]);

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const response = await api.get(`/events?userId=${user.id}`);  // Fetch user-specific events
        setEvents(response.data);  // Assume the response data is a list of events
      } catch (error) {
        console.error('Error fetching events:', error);
      }
    };

    if (user) {
      fetchEvents();
    }
  }, [user]);

  if (!user) {
    return <div>No user data available. Please log in.</div>;
  }

  return (
    <div>
      <h1>Welcome, {user.username}!</h1>
      
      <h2>Your Upcoming Events</h2>
      <EventList events={events} />  {/* Pass events to the EventList component */}
    </div>
  );
};

export default DashboardPanel;
